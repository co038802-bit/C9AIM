package com.c9aim.trainer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int hits = 0;
    private int round = 30;
    private TextView score;
    private TextView timer;
    private Button target;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(13, 18, 28));

        TextView title = new TextView(this);
        title.setText("C9 AIM"); title.setTextColor(Color.rgb(0, 230, 170));
        title.setTextSize(32); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("TREINO DE PRECISÃO • MODO PRÁTICA"); subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12); subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.setMargins(0, 8, 0, 28); root.addView(subtitle, sp);

        score = new TextView(this); score.setText("Acertos: 0"); score.setTextColor(Color.WHITE); score.setTextSize(22); score.setGravity(Gravity.CENTER);
        root.addView(score, new LinearLayout.LayoutParams(-1, -2));
        timer = new TextView(this); timer.setText("Toque no alvo para treinar"); timer.setTextColor(Color.LTGRAY); timer.setTextSize(14); timer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2); tp.setMargins(0, 8, 0, 24); root.addView(timer, tp);

        target = new Button(this); target.setText("●\nALVO"); target.setTextSize(20); target.setTextColor(Color.WHITE); target.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 150, 110)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(220, 180); bp.gravity = Gravity.CENTER; bp.setMargins(0, 0, 0, 22); root.addView(target, bp);
        target.setOnClickListener(v -> { hits++; score.setText("Acertos: " + hits); timer.setText("Boa! Continue treinando sua precisão."); target.setTranslationX((float)(Math.random()*80-40)); target.setTranslationY((float)(Math.random()*30-15)); });

        Button reset = new Button(this); reset.setText("REINICIAR TREINO"); reset.setOnClickListener(v -> { hits = 0; score.setText("Acertos: 0"); timer.setText("Toque no alvo para treinar"); target.setTranslationX(0); target.setTranslationY(0); });
        root.addView(reset, new LinearLayout.LayoutParams(-1, -2));
        TextView note = new TextView(this); note.setText("App de treino independente. Não altera o Free Fire nem revela a posição de inimigos."); note.setTextColor(Color.GRAY); note.setTextSize(12); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.setMargins(0, 24, 0, 0); root.addView(note, np);
        setContentView(root);
    }
}
